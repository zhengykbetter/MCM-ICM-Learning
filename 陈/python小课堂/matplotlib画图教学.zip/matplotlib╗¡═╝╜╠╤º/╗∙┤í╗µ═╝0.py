# -*- coding: utf-8 -*-
"""
Created on Tue May  2 15:52:09 2023

@author: WT
"""
#导入需要的常用模块

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  #三维绘图需要用到
plt.rcParams['font.sans-serif'] = ['SimHei']    #显示中文
#这里定义图像的基本内容
fig_width = 15                           #画板宽度
fig_height = 9                           #画板高度
fig_dpi = 100                               #画板上图像的分辨率
fig_background_color = "#00DDAA"              #画板背景颜色
fig_edge_color = 'red'                      #画板边框颜色
#创建一个画板
#以及对画板进行调整
fig = plt.figure(figsize = (fig_width,fig_height),
                            facecolor = fig_background_color,
                            dpi = fig_dpi,
                            edgecolor = fig_edge_color)

#导入或者定义需要被展示的数据
x_data = np.random.rand(40)*10          #所有点在x轴上的坐标，是一个数组
y_data = np.random.rand(40)*10          #所有点在第二个维度上的坐标
z1_data = np.random.rand(40)*10          #...
z2_data = np.random.rand(40)*10+10          #...
#绘制具体的图
subfig1 = fig.add_subplot(1,2,1)     #将画板均分为1行2列，添加位置序号为1的图

#plt.xticks(x_data)
#plot.yticks为默认值,可以仿照xticks设置
#plt.xlim(-1,12)                         #设置x轴的坐标限制，y轴可以用plt.ylim设置



subfig1.plot(np.linspace(0,10,11),[1,4,6,2,7,9,2,5,-2,10,-4],
             marker = 'o',  #数据点的标记样式
             ms = 5  ,       #数据点的标记大小
             lw = 2 ,        #线条粗细，lw值越大线条越粗
             ls = '--'  ,    #线条样式,此处为虚线
             label = "中文标记A" ,   #设置此数据的名字
             )          #bar绘制条形图
subfig1.bar(np.linspace(0,10,11),[1,4,6,2,7,9,2,5,-2,10,-4],
             color = "#00DDBB" ,
             label = "C" ,   #设置此数据的名字
             )          #plot绘制折线图
subfig1.plot(np.linspace(0,10,11),[2,3,8,-2,9,-1,4,9,3,5,9] ,
             marker = '^',  #数据点的标记样式
             ms = 5  ,       #数据点的标记大小
             lw = 2 ,        #线条粗细，lw值越大线条越粗

             label = "B" ,   #设置此数据的名字
             )          #plot绘制折线图
subfig1.legend(loc = 'best',fontsize = 10) #若在绘制之前调用legend，就只能产生空白示例，因为legend只绘制已有的数据示例
subfig1.set(title = "子图1")
subfig2 = fig.add_subplot(2,2,2)     #将画板均分为2行2列，添加位置序号为3的图
subfig2.scatter(x_data,y_data)       #scatter绘制散点图
subfig2.set(title="子图2")
ax3D = fig.add_subplot(2,2,4,projection = "3d")    #子图用projection参数设置为三维图的坐标系
#ax3D = Axes3D(fig)                   #也可以自行创建Axes3D对象
ax3D.scatter(x_data,y_data,zs = z1_data,zdir = "z",c = "#00DDAA",marker = "o",s = 40)
ax3D.scatter(x_data,y_data,zs = z2_data,zdir = "z",c = "#FF5511",marker = "^",s = 40)
ax3D.set(xlabel = "X",ylabel = "Y",zlabel = "Z",title = "三维图")
#plt.title("总标题")#只会重新设置最后一张子图的标题
#显示图像'''
plt.show()                             #显示图像

