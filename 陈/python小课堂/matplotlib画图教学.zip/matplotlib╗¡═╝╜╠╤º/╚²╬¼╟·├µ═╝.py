# -*- coding: utf-8 -*-
"""
Created on Tue May 16 16:36:12 2023

@author: WT
"""

import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei']    #显示中文
plt.rcParams['axes.unicode_minus'] = False    #显示正负号
fig = plt.figure()
ax = fig.add_subplot(projection = "3d")
x = np.arange(-20,+20,0.5)
y = np.arange(-20,+20,0.5)
x,y = np.meshgrid(x, y)
z = np.sqrt(x**2+y**2)
surf = ax.plot_surface(x,y,z,rstride = 1,cstride = 1,cmap = plt.cm.viridis)#rstride表示行步长，cmap给曲面添加色彩
fig.colorbar(surf)#添加颜色映射的标注
ax.set_xlabel("X Label")
ax.set_ylabel("Y Label")
ax.set_zlabel("Z Label")

ax.set_title("3D曲面图")
plt.show()