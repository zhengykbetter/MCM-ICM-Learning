# -*- coding: utf-8 -*-
"""
Created on Tue May  2 18:44:58 2023

@author: WT
"""

import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']    #显示中文
plt.rcParams['axes.unicode_minus'] = False    #显示正负号

labels = ['区域1','区域2','区域3']
data = [30,30,40]
plt.axis('equal')
plt.pie(data,                 #比例
        labels = labels,      #标签
        autopct = '%0.2f%%',  #保留小数位数
        shadow = True,        #立体阴影效果
        explode = [0,0,0.2]   #列表中第x项对应第x类的扇形的与中心分离距离，用来突出显示
        )
plt.title("标题",fontsize = 24)#设置图像的标题和标题文字大小
plt.show()
