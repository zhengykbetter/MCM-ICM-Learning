# -*- coding: utf-8 -*-
"""
Created on Tue May  2 18:40:45 2023

@author: WT
"""


import numpy as np

import matplotlib.pyplot as plt
#plt.rcParams['font.sans-serif'] = ['SimHei']    #显示中文
#plt.rcParams['axes.unicode_minus'] = False    #显示正负号

x = [1,2,3,4,5]
y = np.random.rand(3,5)*10

fig1 = plt.figure(figsize = (10,8))
plt.bar(x ,y[0],color = "blue",width = 0.5,label = "type1",bottom = 0)
plt.bar(x ,y[1],color = "red",width = 0.5,label = "type2",bottom = y[0])
plt.bar(x ,y[2],color = "yellow",width = 0.5,label = "type2",bottom = y[0] + y[1])
plt.title("fig1",fontsize = 24)#设置图像的标题和标题文字大小
plt.xlabel("fig1.x",fontsize = 14)
plt.ylabel("fig1.y",fontsize = 14)
x_t = ["中文名称1","中文名称2","type3","type4","type5"]
plt.xticks(x,x_t)
plt.xlim(0,7)
plt.legend(loc = "upper right",fontsize = 10)
plt.show()