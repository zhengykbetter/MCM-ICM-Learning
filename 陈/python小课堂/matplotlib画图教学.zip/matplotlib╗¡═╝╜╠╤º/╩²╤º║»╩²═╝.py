# -*- coding: utf-8 -*-
"""
Created on Fri May 12 17:13:01 2023

@author: WT
"""

import numpy as np

import matplotlib.pyplot as plt

t = np.arange(-2*np.pi,2*np.pi,0.01)
s = np.sin(2*np.pi*t)


plt.xlim((-2*np.pi,2*np.pi))
plt.ylim((-1.5,1.5))#设置坐标轴的范围

plt.xlabel("X")
plt.ylabel("Y")#坐标轴描述

plt.plot(t,s)

new_ticks = np.linspace(-2*np.pi,2*np.pi,8)
plt.xticks(new_ticks)#重新设置x轴坐标
'''plt.yticks([-1,-0.5,0,0.5,1],
           ["状态0","状态1","状态2","状态3","状态4"])#指定位置设置y轴坐标标注'''

ax = plt.gca()#获取坐标轴gca
ax.spines["right"].set_color("#00DDBB")#设置右边框颜色
ax.spines["top"].set_color("#00DDAA")#设置上边框颜色

#ax.spines["right"].set_color("none")#去掉右边框颜色
#ax.spines["top"].set_color("none")#去掉上边框颜色

ax.xaxis.set_ticks_position("bottom")#设置x轴刻度
ax.yaxis.set_ticks_position("left")#设置y轴刻度

ax.spines["bottom"].set_position(("data",-1.5))#设置bottom对应0点，此处就是x轴
ax.spines["left"].set_position(("data",-2*np.pi))#设置left对应0点,此处就是y轴

plt.show()

