# -*- coding: utf-8 -*-
"""
Created on Tue May  2 18:07:16 2023

@author: WT
"""


import numpy as np

import matplotlib.pyplot as plt


x1 = [1,2,3,4,5]
x2 = [1.5,2.5,3.5,4.5,5.5]
y1 = np.random.rand(5)*10
y2 = np.random.rand(5)*10
fig1 = plt.figure(figsize = (10,4))
plt.bar(x1,y1,color = "blue",width = 0.5,label = "type1")
plt.bar(x2,y2,color = "red",width = 0.5,label = "type2")
for x,y,i in zip(x1,y1,range(len(x1))):
    plt.text(x,y+0.02,"%.1f"%y1[i],ha = 'center',fontsize = 10)#标注每个数据点
plt.title("fig1",fontsize = 24)#设置图像的标题和标题文字大小
plt.xlabel("fig1.x",fontsize = 14)
plt.ylabel("fig1.y",fontsize = 14)
x_t = ["type1","type2","type3","type4","type5"]
plt.xticks(x1,x_t)
plt.xlim(0,7)
plt.legend(loc = "upper right",fontsize = 10)
plt.show()
